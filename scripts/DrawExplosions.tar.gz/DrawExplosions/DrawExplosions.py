#! /usr/bin/python

import os
import string
import itertools
import subprocess

CHAR_PATH = '../assets/Chars/'


def extractNo(filename):
    ascii = string.punctuation + string.ascii_letters
    trans = str.maketrans('', '', ascii)
    return int(filename.translate(trans))


def sortImages(imageSet):
    "Takes an image set and arranges them in animation order."
    return sorted(imageSet, key=extractNo)


def loadAnims(charName):
    "Gets all animations for the given character."
    images = {}
    path = os.path.join('../Walk')
    tree = os.walk(path)
    tree.__next__()
    for dirpath, dirnames, filenames in tree:
        direction = os.path.basename(dirpath)
        loadedImgs = [os.path.join(path, direction, image)
                      for image in sortImages(filenames)]
        images[os.path.basename(dirpath)] = loadedImgs
    return images


def loadExplosions(charName):
    tree = os.walk('Explosion')
    _, _, filenames = tree.__next__()
    return itertools.cycle([os.path.join('Explosion', fn)
                           for fn in sortImages(filenames)])

anim = loadAnims('Dave')
expls = loadExplosions('Dave')
for direction in anim.keys():
    for i in range(len(anim[direction])):
        next_walk = expls.__next__()
        subprocess.call(
            ['composite', '-geometry', '+25+50', next_walk, anim[direction][i],
             os.path.join(direction, 'tile_' + str(i) + '.png')])
